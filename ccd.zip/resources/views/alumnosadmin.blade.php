@extends('layouts.materialize4')

@section('head')
    Alumnos / asistencias
@endsection

@section('titulo')
    Alumnos / asistencias
@endsection

@section('contenido')

    <livewire:create-alumno />

@endsection