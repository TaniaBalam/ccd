<?php return array (
  'alumnos-maestro' => 'App\\Http\\Livewire\\AlumnosMaestro',
  'create-alumno' => 'App\\Http\\Livewire\\CreateAlumno',
  'crud-admin' => 'App\\Http\\Livewire\\CrudAdmin',
  'crud-alumno' => 'App\\Http\\Livewire\\CrudAlumno',
  'crud-maestro' => 'App\\Http\\Livewire\\CrudMaestro',
  'crud-periodo' => 'App\\Http\\Livewire\\CrudPeriodo',
  'crud-taller' => 'App\\Http\\Livewire\\CrudTaller',
  'perfil-admin' => 'App\\Http\\Livewire\\PerfilAdmin',
  'perfil-alumno' => 'App\\Http\\Livewire\\PerfilAlumno',
  'perfil-maestro' => 'App\\Http\\Livewire\\PerfilMaestro',
  'talleres-alumno' => 'App\\Http\\Livewire\\TalleresAlumno',
);