

<?php $__env->startSection('head'); ?>
    Administradores
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
    Administradores
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('crud-admin', [])->html();
} elseif ($_instance->childHasBeenRendered('U4cz2pX')) {
    $componentId = $_instance->getRenderedChildComponentId('U4cz2pX');
    $componentTag = $_instance->getRenderedChildComponentTagName('U4cz2pX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('U4cz2pX');
} else {
    $response = \Livewire\Livewire::mount('crud-admin', []);
    $html = $response->html();
    $_instance->logRenderedChild('U4cz2pX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('modal'); ?>
    
    <?php if(session('error')): ?>
        <script>
            Swal.fire({
                icon: 'error',
                confirmButtonText: 'Aceptar!',
                title: "<?php echo e(session('error')); ?>",
            })
        </script>
    <?php endif; ?>

    <script>
        Livewire.on('SCreate', modal => {
            $(modal).modal('close');
        })
    </script>

    <script>
        Livewire.on('delete', (userId, adminId) =>{
            Swal.fire({
                title: '¿Estás seguro que quieres eliminar a este administrador?',
                showDenyButton: true,
                confirmButtonText: 'Eliminar',
                denyButtonText: `Cancelar`,
                }).then((result) => {
                /* Read more about isConfirmed, isDenied below */
                if (result.isConfirmed) {
                    Livewire.emitTo('crud-admin','destroye', userId, adminId);
                }
            })
        })
    </script>

    <script>
        Livewire.on('mensaje', (mensaje, icono) => {
            Swal.fire({
                title: mensaje,
                icon: icono,
                confirmButtonColor: '#3085d6',
                confirmButtonText: 'Aceptar'
            })
        })
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.materialize4', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/vistaadmins.blade.php ENDPATH**/ ?>