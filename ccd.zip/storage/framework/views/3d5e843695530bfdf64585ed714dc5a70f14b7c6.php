

<?php $__env->startSection('head'); ?>
    Asistencias
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
    Asistencias <?php echo e(Str::lower($tallers->taller)); ?> <?php echo e($tallers->periodo->periodo); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>


    <?php if($asistencias->count()==0): ?>
        
        <div class="center">
            <p class="white-text cuerpo">Este taller no tiene asistencias aplicadas</p>
            <img class="circle" width="250px" height="250px" src="https://media.istockphoto.com/vectors/cartoon-cute-back-to-school-teacher-cat-writing-paper-vector-vector-id1165676177">
        </div>
    <?php else: ?>

        <form method="POST" action="<?php echo e(route('asisAdmin.update')); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>

            <table class="highlight responsive-table titulo">
                    
                    <thead class="indigo">
                        <th>Matrícula</th>
                        <th>Alumno</th>
                        <th>Fecha</th>
                        <th>Asistencia</th>
                            
                    </thead>
                        
                    <tbody class="white">
                        <?php $__currentLoopData = $asistencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asistencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                            <tr> 
                                <td><?php echo e($asistencia->alumno->matricula); ?></td>
                                <td><?php echo e($asistencia->alumno->user->name); ?> <?php echo e($asistencia->alumno->user->last_name); ?></td>
                                <td><?php echo e($asistencia->fecha); ?></td> 
                                <td>
                                    <select  class="browser-default" id="seleccionar" name="asistencia[]">
                                        <option value="2" <?php if($asistencia->af == 2): ?> selected  <?php endif; ?>   <?php echo e(old('asistencia') == 1 ? 'selected' : ''); ?>>Falta</option>
                                        <option value="1" <?php if($asistencia->af == 1): ?> selected  <?php endif; ?>   <?php echo e(old('asistencia') == 1 ? 'selected' : ''); ?>>Asistencia</option>
                                    </select>

                                </td> 
                            </tr>

                            <input type="hidden" name="idAsistencia[]" value="<?php echo e($asistencia->id); ?>">
            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
                    </tbody>
            </table>
            <br>

            <div class="center">
                <button style="background:#B8860B" class="waves-effect waves-light btn-small">Guardar cambios<i class="material-icons right">save</i></button>
            </div>
            <br>

        </form>

    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>


    <!-- mensaje de actualizar asistencia -->
    <?php if(session('success')): ?>
        <script>
            Swal.fire({
                icon: 'success',
                confirmButtonText: 'Aceptar!',
                title: "<?php echo e(session('success')); ?>",
            })
        </script>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.materialize4', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/editarasistenciasAdmin.blade.php ENDPATH**/ ?>