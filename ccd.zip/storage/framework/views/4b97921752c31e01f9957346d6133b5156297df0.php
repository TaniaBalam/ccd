<div>
    
   
    <div class="row">
        <input class="col m3 s6 white" placeholder="Buscar por nombre" type="text" wire:model="buscador">

        <button class="btn color" style="height:45px" wire:click="render()"><i class="fa-solid fa-magnifying-glass"></i></i></button>
    </div>

    <?php echo $__env->make('livewire.admin.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('livewire.admin.update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <table class="highlight responsive-table titulo">
        
        <thead class="indigo">
           
            <th>Nombre</th>
            <th>Correo institucional</th>
            <th>Acciones</th>                
        </thead>
        
        <tbody class="white">
            <!-- compara si hay usuarios -->
            <?php if($admins->count() <> 0): ?>
                <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                    <tr> 
                                                                
                        <td ><?php echo e($user->name); ?> <?php echo e($user->last_name); ?></td>

                        <td ><?php echo e($user->email); ?></td>
                    
                        <td>  
                            <a style="background:green" class="btn col s12 modal-trigger" href="#modal2" wire:click="edit(<?php echo e($user->id); ?>)"><i class="material-icons">edit</i></a>
                            <a style="background:red" class="btn col s12" wire:click="$emit('delete', <?php echo e($user->id); ?>, <?php echo e($user->admin->id); ?>)" ><i class="material-icons">delete</i></a>
                        </td>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <!-- mensaje de que no hay usuarios -->
            <?php else: ?>
            
                <tr>
                    <td class="center" colspan="3" rowspan="3">
                        <br>
                        <i class="fa-solid fa-triangle-exclamation">&nbsp No se encontraron datos</i>
                        <br></br>
                    </td>
                </tr>
            <?php endif; ?>         
        </tbody>
    </table>
    <br></br>
    <?php echo e($admins->links('vendor.pagination.materializecss')); ?>

</div>
<?php /**PATH C:\xampp\htdocs\project\resources\views/livewire/crud-admin.blade.php ENDPATH**/ ?>