

<?php $__env->startSection('head'); ?>
    Alumnos / asistencias
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
    Alumnos / asistencias
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('create-alumno', [])->html();
} elseif ($_instance->childHasBeenRendered('LhmLTXc')) {
    $componentId = $_instance->getRenderedChildComponentId('LhmLTXc');
    $componentTag = $_instance->getRenderedChildComponentTagName('LhmLTXc');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('LhmLTXc');
} else {
    $response = \Livewire\Livewire::mount('create-alumno', []);
    $html = $response->html();
    $_instance->logRenderedChild('LhmLTXc', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.materialize4', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/alumnosadmin.blade.php ENDPATH**/ ?>