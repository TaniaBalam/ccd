

<?php $__env->startSection('head'); ?>
    Editar alumno
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
    Editar alumno
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <div class="row">
  
        <div class="col s8 offset-s2 black">

            <div class="center">
                <br>
                <img class="circle" src="https://brandem.mx/wp-content/uploads/2018/12/FELINOS_mascota.jpg" width="150px" height="150px">
            </div>

            
            <form method="POST" action="<?php echo e(route('alumnoadmin.update',$Alumno->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>

                <div class="container">


                    <div>
                        <span class="white-text">Taller:</span>
                        <select name="taller" class="<?php $__errorArgs = ['taller'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> browser-default grey lighten-2" >
    
                            <option hidden value="<?php echo e($Alumno->taller->id); ?>"><?php echo e($Alumno->taller->taller); ?></option>
                            
                            <?php $__currentLoopData = $taller; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tallers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tallers->id); ?>" <?php echo e(old('taller') == $tallers->id ? "selected" :""); ?>><?php echo e($tallers->taller); ?> <?php echo e($tallers->periodo->periodo); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        
                        <?php $__errorArgs = ['taller'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="alert alert-danger red-text"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>
                   
                    
                    <div class="input-field">
                        <span class="white-text"> Nombre(s): </span> 
                        <input id="nombre" name="nombre" type="text" class="<?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> grey lighten-2"  value="<?php echo e(old('nombre',$Alumno->user->name)); ?>" autofocus>
                        <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="alert alert-danger red-text"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="input-field">
                        <span class="white-text"> Apellido(s): </span> 
                        <input id="apellido" name="apellido" type="text" class="<?php $__errorArgs = ['apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> grey lighten-2"  value="<?php echo e(old('apellido',$Alumno->user->last_name)); ?>">
                        <?php $__errorArgs = ['apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="alert alert-danger red-text"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="input-field">
                        <span class="white-text"> Correo institucional: </span> 
                        <input disabled  type="text" class="grey lighten-2"  value="<?php echo e($Alumno->user->email); ?>">
                    </div>

                    <div class="input-field">
                        <span class="white-text"> Matrícula: </span> 
                        <input disabled  type="text" class="grey lighten-2"  value="<?php echo e($Alumno->matricula); ?>">
                    </div>


                
                    <div class="input-field">
                        <span class="white-text"> Edad: </span> 
                        <input id="edad" name="edad" type="number" class="<?php $__errorArgs = ['edad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> grey lighten-2"  value="<?php echo e(old('edad',$Alumno->edad)); ?>">

                        <?php $__errorArgs = ['edad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="alert alert-danger red-text"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        
                    </div>


                    <div>
                        <span class="white-text">Sexo:</span>
                        
                        <label>
                            <input class="<?php $__errorArgs = ['sexo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> with-gap" value="1" <?php if($Alumno->sexo == 'Masculino'): ?> checked  <?php endif; ?>  <?php echo e((old('sexo') == 1) ? 'checked' : ''); ?> name="sexo" type="radio" />
                            <span>Masculino</span>
                        </label>
                        
                        <label>
                            <input class="<?php $__errorArgs = ['sexo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> with-gap" value="2" <?php if($Alumno->sexo == 'Femenino'): ?> checked  <?php endif; ?>  <?php echo e((old('sexo') == 2) ? 'checked' : ''); ?> name="sexo" type="radio" />
                            <span>Femenino</span>
                        </label> 

                        <div>
                            <?php $__errorArgs = ['sexo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="alert alert-danger red-text"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                
                    </div>

       

                    <div class="input-field">
                        <span class="white-text"> Teléfono: </span> 
                        <input id="telefono"  name="telefono" type="text" class="<?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> grey lighten-2" value="<?php echo e(old('telefono', $Alumno->telefono)); ?>" >

                        <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="alert alert-danger red-text"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        
                    </div>

                    <div>
                        <span class="white-text">Carrera</span>
                        <select name="carrera" class="<?php $__errorArgs = ['carrera'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> browser-default grey lighten-2">
                            <option value="1" <?php if($Alumno->carrera == 'Ingeniería en Sistemas Computacionales'): ?> selected  <?php endif; ?>   <?php echo e(old('carrera') == 1 ? 'selected' : ''); ?>>Ingeniería en Sistemas Computacionales</option>
                            <option value="2" <?php if($Alumno->carrera == 'Ingeniería Industrial'): ?> selected  <?php endif; ?>   <?php echo e(old('carrera') == 2 ? 'selected' : ''); ?>>Ingeniería Industrial</option>
                            <option value="3" <?php if($Alumno->carrera == 'Ingeniería Electrónica'): ?> selected  <?php endif; ?>   <?php echo e(old('carrera') == 3 ? 'selected' : ''); ?>>Ingeniería Electrónica</option>
                            <option value="4" <?php if($Alumno->carrera == 'Ingeniería en Energías Renovables'): ?> selected  <?php endif; ?>  <?php echo e(old('carrera') == 4 ? 'selected' : ''); ?>>Ingeniería en Energías Renovables</option>
                            <option value="5" <?php if($Alumno->carrera == 'Ingeniería Electromécanica'): ?> selected  <?php endif; ?>  <?php echo e(old('carrera') == 5 ? 'selected' : ''); ?>>Ingeniería Electromécanica</option>
                        </select>

                        <?php $__errorArgs = ['carrera'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="alert alert-danger red-text"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <br>
  
                    <div>
                        <span class="white-text">Cultura etnia:</span>
                        
                        <label>
                            <input class="<?php $__errorArgs = ['culturaetnia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> with-gap" value="1" <?php if($Alumno->culturaetnia == 'Si'): ?> checked  <?php endif; ?>  <?php echo e((old('culturaetnia') == 1) ? 'checked' : ''); ?> name="culturaetnia" type="radio" />
                            <span>Si</span>
                        </label>

                        
                        <label>
                            <input class="<?php $__errorArgs = ['culturaetnia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> with-gap" value="2" <?php if($Alumno->culturaetnia == 'No'): ?> checked  <?php endif; ?>  <?php echo e((old('culturaetnia') == 2) ? 'checked' : ''); ?> name="culturaetnia" type="radio" />
                            <span>No</span>
                        </label> 

                        <div>
                            <?php $__errorArgs = ['culturaetnia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="alert alert-danger red-text"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                
                    </div>
                    <br>

                    <div>
                        <span class="white-text">Municipio:</span>
                        <select name="municipio" class="<?php $__errorArgs = ['municipio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> browser-default grey lighten-2" >
    
                            <option hidden value="<?php echo e($Alumno->municipio->id); ?>"><?php echo e($Alumno->municipio->municipio); ?></option>
                            
                            <?php $__currentLoopData = $municipio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipios): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($municipios->id); ?>" <?php echo e(old('municipio') == $municipios->id ? "selected" :""); ?>><?php echo e($municipios->municipio); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        
                        <?php $__errorArgs = ['municipio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="alert alert-danger red-text"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>
                    <br>

                    <div>
                        <span class="white-text">Discapacidad:</span>
                        
                        <label>
                            <input class="<?php $__errorArgs = ['discapacidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> with-gap" value="1" <?php if($Alumno->discapacidad == 'Si'): ?> checked  <?php endif; ?>  <?php echo e((old('discapacidad') == 1) ? 'checked' : ''); ?> name="discapacidad" type="radio" />
                            <span>Si</span>
                        </label>
                        
                        <label>
                            <input class="<?php $__errorArgs = ['discapacidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> with-gap" value="2" <?php if($Alumno->discapacidad == 'No'): ?> checked  <?php endif; ?>  <?php echo e((old('discapacidad') == 2) ? 'checked' : ''); ?> name="discapacidad" type="radio" />
                            <span>No</span>
                        </label> 

                        <div>
                            <?php $__errorArgs = ['discapacidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="alert alert-danger red-text"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>
                
                    <br>


                    <div class="center">
                        <button style="background:#1B396A" class="waves-effect waves-light btn-small">Enviar datos<i class="fa-solid fa-paper-plane right"></i></button>
                    </div>

                </div>

            </form>

        <br>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.materialize4', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/actualizaralumnoadmin.blade.php ENDPATH**/ ?>