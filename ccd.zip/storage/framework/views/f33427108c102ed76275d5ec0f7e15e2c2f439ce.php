<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">

    <style>
        p{
            font-size:large;
        }
    </style>

</head>
<body>

    <div class="row">
        <div class="col s3">
            <img src="https://media-exp1.licdn.com/dms/image/C4D0BAQHoTZZrPwrFFA/company-logo_200_200/0/1616521635687?e=2147483647&v=beta&t=k9q4ftaYtT6qZUMW3IK8au66ah-lQU_iCKY3s8vc9yo" width="80px" height="80px">
        </div>
        <div class="col s6">
            <!-- <img src="https://www.tijuana.tecnm.mx/wp-content/uploads/2021/08/liston-de-logos-oficiales-educacion-tecnm-FEB-2021-1568x287.jpg" width="330px" height="80px"> -->
        </div>
        <div class="col s3">
            <img src="http://mdkonline.com.mx/uploads/posts/c6w5u515jq.jpg" width="110px" height="90px">
        </div>
        
    </div>

    <div class="container">
        
        <h3>Constancia de cumplimiento de actividad complementaria</h3>
        <p> El que suscribe el maestro <?php echo e($Alumno->taller->maestro->user->name); ?> <?php echo e($Alumno->taller->maestro->user->last_name); ?> 
            por este medio se permite hacer de su conocimiento que el/la estudiante 
            <?php echo e($Alumno->user->name); ?> <?php echo e($Alumno->user->last_name); ?> con número de control <?php echo e($Alumno->matricula); ?>

            de la carrera de <?php echo e($Alumno->carrera); ?> ha cumplido su actividad complementaria en el taller de
            <?php echo e($Alumno->taller->taller); ?> durante el periodo escolar <?php echo e($Alumno->taller->periodo->periodo); ?>

            con un valor curricular de 1 crédito.
            Se extiende la presente en la ciudad de Motul, Yucatán el <?php echo e($date); ?>.
        </p>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\project\resources\views/acreditacion.blade.php ENDPATH**/ ?>