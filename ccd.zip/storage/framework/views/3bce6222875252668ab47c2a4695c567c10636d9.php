<div>
    <?php if(empty($Alumno->taller_id)): ?>

        <h6 class="white-text center cuerpo">Inscríbete a uno de los siguientes talleres</h6>

        <p class="white-text center cuerpo">Si no te gustan los deportes no te preocupes, puedes inscribirte a los talleres culturales</p>

        <div class="row">


        <?php $__currentLoopData = $tallers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col s12 m6">

                <div class="card medium sticky-action">
                    <div class="card-image waves-effect waves-block waves-light">
                        <img class="activator" src="<?php echo e($taller->imagen); ?>" height="200px">
                    </div>

                    <div class="card-content">
                        <span class="card-title activator grey-text text-darken-4"><b><?php echo e($taller->taller); ?> <?php echo e($taller->periodo->periodo); ?></b><i class="material-icons right">more_vert</i></span>
                        <p>Descripción: <?php echo e(Str::limit ($taller->descripcion, 90)); ?></p>
                    </div>

                    <div class="card-action center">
                        <a style="background:#1B396A" class="waves-effect waves-light btn" wire:click="$emit('inscripcion', <?php echo e($taller->id); ?>)">¡Inscribirse! <i class="material-icons">create</i></a>
                    </div>

                    <div class="card-reveal">
                        <span class="card-title grey-text text-darken-4"><b><?php echo e($taller->taller); ?> <?php echo e($taller->periodo->periodo); ?></b><i class="material-icons right">close</i></span>
                        <p>Descripción: <?php echo e($taller->descripcion); ?></p>
                        <p>Horario: <?php echo e($taller->horario); ?></p>
                        
                        
                        <p>Maestro: <?php echo e($taller->maestro->user->name .' '. $taller->maestro->user->last_name); ?></p>   
                        
                            
                                
                            
                    </div>
                    
                </div>

            </div>

            

                
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    <?php else: ?>

        <p class="white-text center cuerpo">Este es el taller al que te inscribiste</p>

    
        <div class="row">
            <div class="col s12 m6">

                <div class="card medium sticky-action">
                    <div class="card-image waves-effect waves-block waves-light">
                        <img class="activator" src="<?php echo e($Alumno->taller->imagen); ?>" height="200px">
                    </div>

                    <div class="card-content">
                        <span class="card-title activator grey-text text-darken-4"><b><?php echo e($Alumno->taller->taller); ?> <?php echo e($Alumno->taller->periodo->periodo); ?></b><i class="material-icons right">more_vert</i></span>
                        <p>Descripción: <?php echo e(Str::limit ($Alumno->taller->descripcion, 90)); ?></p>
                    </div>

                    <div class="card-action center">
                        <a style="color:#B8860B" href="<?php echo e(route('asistenciaalumno')); ?>"><i class="material-icons">assignment_turned_in</i>Asistencias</a>
                    </div>

                    <div class="card-reveal">
                        <span class="card-title grey-text text-darken-4"><b><?php echo e($Alumno->taller->taller); ?> <?php echo e($Alumno->taller->periodo->periodo); ?></b><i class="material-icons right">close</i></span>
                        <p>Descripción: <?php echo e($Alumno->taller->descripcion); ?></p>
                        <p>Horario: <?php echo e($Alumno->taller->horario); ?></p>
                        
                        
                        <p>Maestro: <?php echo e($Alumno->taller->maestro->user->name .' '. $Alumno->taller->maestro->user->last_name); ?></p>   
                        
                            
                                
                            
                    </div>
                    
                </div>

            </div>

        </div>
        <br><br>
        <br><br>

        <?php if(now()->toDateString()>=$Alumno->taller->periodo->fecha_expiracion): ?>
            <a href="/alumno/asistencias" class="btn-flotante">El periodo acabó al fin puedes ir a <br> revisar tu documento de acreditación</a>
        <?php else: ?>
            <a href="/alumno/asistencias" class="btn-flotante">¡Faltan <?php echo e($diasDiferencia); ?> días para que acabe el periodo <br> y puedas descargar tu acreditación!</a>
        <?php endif; ?>

    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\project\resources\views/livewire/talleres-alumno.blade.php ENDPATH**/ ?>