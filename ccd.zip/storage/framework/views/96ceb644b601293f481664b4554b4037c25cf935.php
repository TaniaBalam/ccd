

<?php $__env->startSection('head'); ?>
    Alumnos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
    Alumnos en <?php echo e(Str::lower($tallers->taller)); ?> <?php echo e($tallers->periodo->periodo); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

    <?php if($alumnos->count() == 0): ?>

        <div class="center">
            <p class="white-text">Aún no se han inscrito tus alumnos en el taller</p>
            <img class="circle" width="250px" height="250px" src="https://i0.wp.com/gatolia.com/wp-content/uploads/2021/04/dibujos-animados-lindo-regreso-escuela-gatos-leyendo-libro_39961-1362.jpg?resize=626%2C450&ssl=1">
        </div>
        
    <?php else: ?>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('alumnos-maestro', ['idtaller' => $tallers->id])->html();
} elseif ($_instance->childHasBeenRendered('Brgt3lv')) {
    $componentId = $_instance->getRenderedChildComponentId('Brgt3lv');
    $componentTag = $_instance->getRenderedChildComponentTagName('Brgt3lv');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Brgt3lv');
} else {
    $response = \Livewire\Livewire::mount('alumnos-maestro', ['idtaller' => $tallers->id]);
    $html = $response->html();
    $_instance->logRenderedChild('Brgt3lv', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <?php endif; ?>
        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.materialize3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/alumnos2maestro.blade.php ENDPATH**/ ?>