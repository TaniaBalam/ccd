<div>
 
    <div class="row">
    
    <div class="col s12 m8 offset-m2 black">

    
        <div class="center">
            <br>
            <img class="circle" src="<?php echo e($urlimagen); ?>" width="150px" height="150px">
            
            <a style="background:#1B396A" href="#perfil" class="waves-effect waves-light btn-small modal-trigger"><i class="material-icons ">create</i></a>
        </div>

        <?php echo $__env->make('livewire.perfil.perfil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <form wire:submit.prevent="update">

            <div class="container cuerpo">

                <input wire:model="idadmin" id="nombre" name="nombre" type="hidden" class="grey lighten-2">

                <div class="input-field">
                    <span class="white-text"> Nombre(s): </span> 
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="red-text"> <?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input wire:model="name" id="nombre" name="nombre" type="text" class="grey lighten-2"  value="<?php echo e(old('nombre',$admin->name)); ?>">
                </div>

                <div class="input-field">
                    <span class="white-text"> Apellido(s): </span> 
                    <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="red-text"> <?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input wire:model="last_name" id="apellido" name="apellido" type="text" class="<?php $__errorArgs = ['apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> grey lighten-2"  value="<?php echo e(old('apellido',$admin->last_name)); ?>">
                </div>

                <div class="input-field">
                    <span class="white-text"> Correo institucional: </span> 
                    <input disabled  type="text" class="grey lighten-2"  value="<?php echo e($admin->email); ?>">
                </div>

                <div class="center">
                    <button  style="background:#1B396A" type="submit" class="waves-effect waves-light btn-small">Guardar cambios<i class="material-icons right">save</i></button>
                </div>
            </div>
        </form>
        <br>
    </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\project\resources\views/livewire/perfil-admin.blade.php ENDPATH**/ ?>