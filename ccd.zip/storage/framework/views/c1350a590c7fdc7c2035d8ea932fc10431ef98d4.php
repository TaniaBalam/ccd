

<?php $__env->startSection('head'); ?>
    Datos personales del alumno
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
    Datos personales del alumno
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>


<div class="row cuerpo">

    <div class="container">
        <div class="card white">
            <b><p style="color:#1B396A;font-size:larger" class="center">¡Ya casi acabas tu registro! Solo necesitamos que nos proporciones algo más de información sobre ti.</p></b>
        </div>
    </div>
  
  <div class="col s8 offset-s2 white">
        <div class="center">
            <br>

            <img class="circle" src="https://brandem.mx/wp-content/uploads/2018/12/FELINOS_mascota.jpg" width="150px" height="150px">
        </div>

        

        <form method="POST" action="/alumno/store">
            <?php echo csrf_field(); ?>

            <div class="container">

                
                <div class="input-field">
                    <span> Edad: </span> 
                    <input id="edad" name="edad" type="number" class="<?php $__errorArgs = ['edad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> grey lighten-2"  value="<?php echo e(old('edad')); ?>" autofocus>

                    <?php $__errorArgs = ['edad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="alert alert-danger red-text"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    
                </div>


                <div>
                    <span>Sexo:</span>
                    
                    <label>
                        <input class="<?php $__errorArgs = ['sexo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> with-gap" value="1" <?php echo e((old('sexo') == 1) ? 'checked' : ''); ?> name="sexo" type="radio" />
                        <span>Masculino</span>
                    </label>
                    
                    <label>
                        <input class="<?php $__errorArgs = ['sexo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> with-gap" value="2" <?php echo e((old('sexo') == 2) ? 'checked' : ''); ?> name="sexo" type="radio" />
                        <span>Femenino</span>
                    </label> 

                    <div>
                        <?php $__errorArgs = ['sexo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="alert alert-danger red-text"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
            
                </div>

       

                <div class="input-field">
                    <span> Teléfono: </span> 
                    <input id="telefono"  name="telefono" type="text" class="<?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> grey lighten-2" value="<?php echo e(old('telefono')); ?>" >

                    <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="alert alert-danger red-text"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    
                </div>

                <div>
                    <span>Carrera</span>
                    <select name="carrera" class="<?php $__errorArgs = ['carrera'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> browser-default grey lighten-2">
                        <option value="" disabled selected></option>
                        <option value="1" <?php echo e(old('carrera') == 1 ? 'selected' : ''); ?>>Ingeniería en Sistemas Computacionales</option>
                        <option value="2" <?php echo e(old('carrera') == 2 ? 'selected' : ''); ?>>Ingeniería Industrial</option>
                        <option value="3" <?php echo e(old('carrera') == 3 ? 'selected' : ''); ?>>Ingeniería Electrónica</option>
                        <option value="4" <?php echo e(old('carrera') == 4 ? 'selected' : ''); ?>>Ingeniería en Energías Renovables</option>
                        <option value="5" <?php echo e(old('carrera') == 5 ? 'selected' : ''); ?>>Ingeniería Electromécanica</option>
                    </select>

                    <?php $__errorArgs = ['carrera'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="alert alert-danger red-text"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <br>
  
                <div>
                    <span>Cultura etnia:</span>
                    
                    <label>
                        <input class="<?php $__errorArgs = ['culturaetnia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> with-gap" value="1" <?php echo e((old('culturaetnia') == 1) ? 'checked' : ''); ?> name="culturaetnia" type="radio" />
                        <span>Si</span>
                    </label>
                    
                    <label>
                        <input class="<?php $__errorArgs = ['culturaetnia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> with-gap" value="2" <?php echo e((old('culturaetnia') == 2) ? 'checked' : ''); ?> name="culturaetnia" type="radio" />
                        <span>No</span>
                    </label> 

                    <div>
                        <?php $__errorArgs = ['culturaetnia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="alert alert-danger red-text"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
            
                </div>
                <br>

                <div>
                    <span>Municipio:</span>
                    <select name="municipio" class="<?php $__errorArgs = ['municipio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> browser-default grey lighten-2" >
                        <option value="" disabled selected></option>
                        
                        <?php $__currentLoopData = $municipio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipios): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($municipios->id); ?>" <?php echo e(old('municipio') == $municipios->id ? "selected" :""); ?>><?php echo e($municipios->municipio); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    
                    <?php $__errorArgs = ['municipio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="alert alert-danger red-text"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
                <br>

                <div>
                    <span>Discapacidad:</span>
                    
                    <label>
                        <input class="<?php $__errorArgs = ['discapacidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> with-gap" value="1" <?php echo e((old('discapacidad') == 1) ? 'checked' : ''); ?> name="discapacidad" type="radio" />
                        <span>Si</span>
                    </label>
                    
                    <label>
                        <input class="<?php $__errorArgs = ['discapacidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> with-gap" value="2" <?php echo e((old('discapacidad') == 2) ? 'checked' : ''); ?> name="discapacidad" type="radio" />
                        <span>No</span>
                    </label> 

                    <div>
                        <?php $__errorArgs = ['discapacidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="alert alert-danger red-text"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                </div>
                
                <br>

                    
                <div class="center">
                    <button style="background:#1B396A" class="waves-effect waves-light btn-small">Enviar datos<i class="fa-solid fa-paper-plane right" ></i></button>
                </div>

            </div>
            
        </form>
        
        <br>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    <?php if(session('error')): ?>
        <script>
            Swal.fire({
                icon: 'error',
                confirmButtonText: 'Aceptar!',
                title: "<?php echo e(session('error')); ?>",
            })
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.materialize', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/crearalumno.blade.php ENDPATH**/ ?>