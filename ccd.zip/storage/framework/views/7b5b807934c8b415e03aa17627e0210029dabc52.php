<div>

    <div class="row">
        <input class="col m3 s6 white" placeholder="Buscar por taller" type="text" wire:model="buscador">

        <button class="btn color" style="height:45px" wire:click="render()"><i class="fa-solid fa-magnifying-glass"></i></i></button>
    </div>

    <?php echo $__env->make('livewire.alumno.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="row cuerpo">
        <?php if($tallers->count() <> 0): ?>
            <?php $__currentLoopData = $tallers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col s12 l6">
                    <ul class="collection">
                        <li class="collection-item avatar">
                            <b><span class="title"><?php echo e($taller->taller); ?> <?php echo e($taller->periodo->periodo); ?></span></b>
                            <img src="<?php echo e($taller->imagen); ?>" alt="" class="circle">
                            <p>Número de alumnos: <?php echo e($taller->alumnos->count()); ?></p>
                            <br>
                            <p ><a class="color-base cambiar" href="<?php echo e(route('vistaveralumnosadmin', $taller->id)); ?>"><i class="material-icons">group</i>Alumnos</a></p>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar alumno')): ?> 
                                <p><a class="color-base cambiar" href="<?php echo e(route('vistaverasis', $taller->id)); ?>"><i class="material-icons">assignment_turned_in</i>Asistencias</a></p>
                            <?php endif; ?>

                            <p><a class="color-base cambiar" href="<?php echo e(route('reporteasistenciaAdmin', $taller->id)); ?>"><i class="material-icons">event_note</i>Reporte de asistencias</a></p>
                            
                        </li>
                    </ul>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            
            <div class="center">
                <p class="white-text">No se encontraron talleres</p>
                <img class="circle" width="250px" height="250px" src="https://i0.wp.com/gatolia.com/wp-content/uploads/2021/04/dibujos-animados-lindo-regreso-escuela-gatos-leyendo-libro_39961-1362.jpg?resize=626%2C450&ssl=1">
            </div>

        <?php endif; ?>
    </div>

    <?php echo e($tallers->links('vendor.pagination.materializecss')); ?>


</div><?php /**PATH C:\xampp\htdocs\project\resources\views/livewire/create-alumno.blade.php ENDPATH**/ ?>