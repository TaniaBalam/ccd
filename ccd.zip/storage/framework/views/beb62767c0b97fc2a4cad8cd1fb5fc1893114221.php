<div>

   
    <div class="row">
        <input class="col m3 s6 white" placeholder="Buscar por nombre" type="text" wire:model="buscador">

        <button class="btn color" style="height:45px" wire:click="render()"><i class="fa-solid fa-magnifying-glass"></i></i></button>
    </div>
    
    <?php echo $__env->make('livewire.alumno.update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <table style="font-size:small"class="highlight responsive-table titulo">
        
        <thead class="indigo">
           
            <th>Nombre</th>
            <th>Correo institucional</th>
            <th>Edad</th> 
            <th>Sexo</th> 
            <th>Teléfono</th>
            <th>Carrera</th>
            <th>Matrícula</th>
            <th>Cultura etnia</th>
            <th>Municipio</th>
            <th>Discapacidad</th>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('eliminar alumno')): ?>
                <th>Acciones</th>
            <?php endif; ?>   

        </thead>
        
        <tbody class="white">
            <!-- compara si hay usuarios -->
            <?php if($admins->count() <> 0): ?>
                <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
                        <tr>                         
                            <td ><?php echo e($user->name); ?> <?php echo e($user->last_name); ?></td>
                            <td ><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->alumno->edad); ?></td>
                            <td><?php echo e($user->alumno->sexo); ?></td>
                            <td><?php echo e($user->alumno->telefono); ?></td>
                            <td><?php echo e($user->alumno->carrera); ?></td>
                            <td><?php echo e($user->alumno->matricula); ?></td>
                            <td><?php echo e($user->alumno->culturaetnia); ?></td>
                            <td><?php echo e($user->alumno->municipio->municipio); ?></td>
                            <td><?php echo e($user->alumno->discapacidad); ?></td>
                        
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('eliminar alumno')): ?>
                                <td>  
                                    <div >
                                        <a style="background:green" class="btn col s12 modal-trigger" href="#modal2" wire:click="edit(<?php echo e($user->id); ?>)"><i class="material-icons">edit</i></a>
                                    </div>
                                    <br>
                                    <div>
                                        <a style="background:red" class="btn col s12" wire:click="$emit('delete', <?php echo e($user->id); ?>, <?php echo e($user->alumno->id); ?>)" ><i class="material-icons">delete</i></a>
                                    </div>
                                </td>
                            <?php endif; ?>
                        </tr>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <!-- mensaje de que no hay usuarios -->
            <?php else: ?>
                
                <tr>
                    <td class="center" colspan="11" rowspan="3">
                        <br>
                        <i class="fa-solid fa-triangle-exclamation">&nbsp No se encontraron datos</i>
                        <br></br>
                    </td>
                </tr>
            <?php endif; ?>         
        </tbody>
    </table>
    <br></br>

    <?php echo e($admins->links('vendor.pagination.materializecss')); ?>


</div>



<?php /**PATH C:\xampp\htdocs\project\resources\views/livewire/crud-alumno.blade.php ENDPATH**/ ?>