<div>

    <div class="row">
        <input class="col m3 s6 white" placeholder="Buscar por nombre" type="text" wire:model="buscador">

        <button class="btn color cambiar" style="height:45px" wire:click="render()"><i class="fa-solid fa-magnifying-glass"></i></i></button>
    </div>

    <table class="highlight responsive-table titulo">
                
        <thead class="indigo">
            <th>Nombre</th>
            <th>Correo institucional</th>
            <th>Carrera</th>
            <th>Matrícula</th>
            <th>Municipio</th>                
        </thead>
        
        <tbody class="white">
            <?php if($alumnos->count() <> 0): ?>
                <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                    <tr> 
                        <td><?php echo e($user->name .' '. $user->last_name); ?></td>                                           
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->alumno->carrera); ?></td>
                        <td><?php echo e($user->alumno->matricula); ?></td>
                        <td><?php echo e($user->alumno->municipio->municipio); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td class="center" colspan="5">
                        <br>
                        <i class="fa-solid fa-triangle-exclamation">&nbsp No se encontraron datos</i>
                        <br></br>
                    </td>
                </tr>
            <?php endif; ?>            
        </tbody>
    </table>
    <br>
    <?php echo e($alumnos->links('vendor.pagination.materializecss')); ?>

</div><?php /**PATH C:\xampp\htdocs\project\resources\views/livewire/alumnos-maestro.blade.php ENDPATH**/ ?>