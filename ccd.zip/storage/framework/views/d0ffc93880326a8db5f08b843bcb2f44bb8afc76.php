
<div>
 
    <div class="row">
        <input class="col m3 s6  white" placeholder="Buscar por periodo" type="text" wire:model="buscador">

        <button class="btn color" style="height:45px" wire:click="render()"><i class="fa-solid fa-magnifying-glass"></i></i></button>
    </div>


    <?php echo $__env->make('livewire.periodo.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('livewire.periodo.update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <table class="highlight responsive-table titulo">
        
        <thead class="indigo">
            <th>Periodo</th>
            <th>Fecha de emisión</th>
            <th>Fecha de expiración</th>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('eliminar alumno')): ?>
                <th>Acciones</th>
            <?php endif; ?>
                         
        </thead>
        
        <tbody class="white">
            <?php if($periodos->count() <> 0): ?>
                <?php $__currentLoopData = $periodos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $periodo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                    <tr> 
                        <td><?php echo e($periodo->periodo); ?></td>     
                        <td><?php echo e($periodo->fecha_emision); ?></td>
                        <td><?php echo e($periodo->fecha_expiracion); ?></td>                                           
            
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('eliminar alumno')): ?>
                            <td>  
                                <a style="background:green" class="btn col s12 modal-trigger" href="#modal2" wire:click="edit(<?php echo e($periodo->id); ?>)"><i class="material-icons">edit</i></a>
                                <a style="background:red" class="btn col s12" wire:click="$emit('delete', <?php echo e($periodo->id); ?>)"><i class="material-icons">delete</i></a>
                            </td>
                        <?php endif; ?>
                        
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td class="center" colspan="4">
                        <br>
                        <i class="fa-solid fa-triangle-exclamation">&nbsp No se encontraron datos</i>
                        <br></br>
                    </td>
                </tr>
            <?php endif; ?>                
        </tbody>
    </table>
    <br><br>
    <?php echo e($periodos->links('vendor.pagination.materializecss')); ?>

</div>
<?php /**PATH C:\xampp\htdocs\project\resources\views/livewire/crud-periodo.blade.php ENDPATH**/ ?>