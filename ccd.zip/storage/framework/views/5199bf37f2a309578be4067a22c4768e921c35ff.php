    
<!-- Modal Structure -->
<div wire:ignore.self id="modal2" class="modal black cuerpo">

    <div class="center">
        <br>
        <img class="circle" src="https://brandem.mx/wp-content/uploads/2018/12/FELINOS_mascota.jpg" width="100px" height="100px">
    </div>

    <div class="modal-content">
        <form wire:submit.prevent="update">
            <input type="hidden"  class="grey lighten-2" wire:model="taller_id" >

            <span class="white-text"> Nombre del taller: </span>
            <?php $__errorArgs = ['taller'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="red-text"> <?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <input wire:model="taller" id="taller" name="taller" type="text" class="grey lighten-2"  value="<?php echo e(old('taller')); ?>" autofocus>

            <span class="white-text"> Descripción: </span> 
            <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="red-text"> <?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <textarea wire:model="descripcion" id="descripcion" name="descripcion" cols="30" rows="10" placeholder="En este taller aprenderas..." class="grey lighten-2 largo"></textarea>

            <span class="white-text">Maestro:</span>
            <?php $__errorArgs = ['maestro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="red-text"> <?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <select wire:model="maestro" name="maestro" class="browser-default grey lighten-2" >

                <?php if($maestro == "Sin maestro"): ?>
                    <option hidden value="">Sin maestro</option>
                <?php else: ?>
                    <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($usuario->hasRole('maestro') and $maestro == $usuario->name): ?>
                            <option hidden value=""><?php echo e($usuario->name . ' ' . $usuario->last_name); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                
                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($usuario->hasRole('maestro')): ?>
                        <option value="<?php echo e($usuario->maestro->id); ?>" <?php echo e(old('maestro') == $usuario->maestro->id ? "selected" :""); ?>><?php echo e($usuario->name . ' ' . $usuario->last_name); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <span class="white-text"> Horario: </span> 
            <?php $__errorArgs = ['horario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="red-text"> <?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <input wire:model="horario" id="horario" name="horario" type="text" class="grey lighten-2"  value="<?php echo e(old('horario')); ?>">

            
            <span class="white-text">Periodo:</span>
            <?php $__errorArgs = ['periodo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="red-text"> <?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <select wire:model="periodo" name="periodo" class="browser-default grey lighten-2" >
                 
              
                <?php $__currentLoopData = $periodos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($p->periodo == $periodo): ?>
                        <option hidden value="" ><?php echo e($p->periodo); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $periodos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $periodo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($periodo->id); ?>" <?php echo e(old('periodo') == $periodo->id ? "selected" :""); ?>><?php echo e($periodo->periodo); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <span class="white-text"> URL de la imagen: </span>
            <?php $__errorArgs = ['imagen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="red-text"> <?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
            <input wire:model="imagen" id="imagen" name="imagen" type="text" class="grey lighten-2"  value="<?php echo e(old('imagen')); ?>">

            <div class="modal-footer black">
                <button  style="background:#1B396A" type="submit" class="waves-effect waves-light btn-small">Guardar cambios<i class="material-icons left">save</i></button>
                
                <button style="background:#BF0820" wire:click="resetInput()" type="button" class="modal-close waves-effect btn-small">Cerrar<i class="fa-solid fa-xmark right"></i></button>
            </div>
        </form>
    </div>
</div><?php /**PATH C:\xampp\htdocs\project\resources\views/livewire/taller/update.blade.php ENDPATH**/ ?>