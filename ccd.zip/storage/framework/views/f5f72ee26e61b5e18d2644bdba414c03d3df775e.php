

<?php $__env->startSection('head'); ?>
    Alumnos en <?php echo e(Str::lower($tallers->taller)); ?> <?php echo e($tallers->periodo->periodo); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
    Alumnos en <?php echo e(Str::lower($tallers->taller)); ?> <?php echo e($tallers->periodo->periodo); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>


    <?php if($alumnos->count() == 0): ?>
        
        <div class="center">
            <p class="white-text">Aún no se han inscrito alumnos en el taller</p>
            <img class="circle" width="250px" height="250px" src="https://i0.wp.com/gatolia.com/wp-content/uploads/2021/04/dibujos-animados-lindo-regreso-escuela-gatos-leyendo-libro_39961-1362.jpg?resize=626%2C450&ssl=1">
        </div>

    <?php else: ?>
     
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('crud-alumno', ['idtaller' => $idtaller])->html();
} elseif ($_instance->childHasBeenRendered('I8Iqnuo')) {
    $componentId = $_instance->getRenderedChildComponentId('I8Iqnuo');
    $componentTag = $_instance->getRenderedChildComponentTagName('I8Iqnuo');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('I8Iqnuo');
} else {
    $response = \Livewire\Livewire::mount('crud-alumno', ['idtaller' => $idtaller]);
    $html = $response->html();
    $_instance->logRenderedChild('I8Iqnuo', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <br></br>

    <?php endif; ?>
        

<?php $__env->stopSection(); ?>


<?php $__env->startSection('modal'); ?>
    <script>
        Livewire.on('SCreate', modal => {
            $(modal).modal('close');
        })
    </script>

    <script>
        Livewire.on('delete', (userId, alumnoId) =>{
            Swal.fire({
                title: '¿Estás seguro que quieres eliminar a este alumno?',
                showDenyButton: true,
                confirmButtonText: 'Eliminar',
                denyButtonText: `Cancelar`,
                }).then((result) => {
                /* Read more about isConfirmed, isDenied below */
                if (result.isConfirmed) {
                    Livewire.emitTo('crud-alumno','destroye', userId, alumnoId);
                }
            })
        })
    </script>

    <script>
        Livewire.on('mensaje', (mensaje, icono) => {
            Swal.fire({
                title: mensaje,
                icon: icono,
                confirmButtonColor: '#3085d6',
                confirmButtonText: 'Aceptar'
            })
        })
    </script>

    <!-- mensaje para registro -->
    <?php if(session('success')): ?>
    <script>
        Swal.fire({
            icon: 'success',
            confirmButtonText: 'Aceptar!',
            title: "<?php echo e(session('success')); ?>",
        })
    </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.materialize4', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/alumnos2admin.blade.php ENDPATH**/ ?>