<?php $__env->startSection('head'); ?>
    Registro
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
    Registro
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<div class="row">
  
  <div class="col s8 offset-s2 white cuerpo">

    <div class="center">
      <br>

      <img class="circle" src="https://brandem.mx/wp-content/uploads/2018/12/FELINOS_mascota.jpg" width="150px" height="150px">
    </div>

      

    <form method="POST" action="<?php echo e(route('register')); ?>">
    <?php echo csrf_field(); ?>

      <div class="container">

        <div class="input-field">
            <span>Nombre(s):</span> 
            <input id="name" name="name" type="text"  class="<?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> grey lighten-2" value="<?php echo e(old('name')); ?>"  autofocus>
            
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span class="alert alert-danger red-text"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
  
        <div class="input-field">
            <span>Apellido(s):</span> 
            <input id="last_name" name="last_name" type="text" class="<?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> grey lighten-2"  value="<?php echo e(old('last_name')); ?>" >

            <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span class="alert alert-danger red-text"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        

        <div class="input-field">
          <span> Correo institucional: </span> 
          <input id="email" name="email" type="email"  class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> grey lighten-2" value="<?php echo e(old('email')); ?>" >

          <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span class="alert alert-danger red-text"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        

        <div class="input-field">
            <span> Contraseña: </span> 
            <input id="password"  name="password" type="password"  class="<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> grey lighten-2" autocomplete="new-password">

            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span class="alert alert-danger red-text"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
      


        <div class="input-field">
          <span> Verificar contraseña: </span>
          <input id="password_confirmation" name="password_confirmation" type="password"  class="grey lighten-2" required>
        </div>
        <br>
      

        <div class="center">
          <button style="background:#1B396A" class="waves-effect waves-light btn-small">Registrarse<i class="fa-solid fa-pen-to-square right" ></i></button>
        </div>

      </div>

  
    </form>

    <div class="center">
      <br>
      <a style="color:#1B396A" href="<?php echo e(route('login')); ?>"><span >¿Ya te has registrado?</span></a>
    </div>
    
    <br>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.materialize', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/auth/register.blade.php ENDPATH**/ ?>