

<?php $__env->startSection('head'); ?>
    Talleres
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
    Talleres
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('crud-taller', [])->html();
} elseif ($_instance->childHasBeenRendered('EMcj6vl')) {
    $componentId = $_instance->getRenderedChildComponentId('EMcj6vl');
    $componentTag = $_instance->getRenderedChildComponentTagName('EMcj6vl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('EMcj6vl');
} else {
    $response = \Livewire\Livewire::mount('crud-taller', []);
    $html = $response->html();
    $_instance->logRenderedChild('EMcj6vl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('modal'); ?>

    <?php if(session('error')): ?>
        <script>
            Swal.fire({
                icon: 'error',
                confirmButtonText: 'Aceptar!',
                title: "<?php echo e(session('error')); ?>",
            })
        </script>
    <?php endif; ?>


    <?php if(session('success')): ?>
        <script>
            Swal.fire({
                icon: 'success',
                confirmButtonText: 'Aceptar!',
                title: "<?php echo e(session('success')); ?>",
            })
        </script>
    <?php endif; ?>

    <?php if(session('actualizar')): ?>
        <script>
            Swal.fire({
                icon: 'success',
                confirmButtonText: 'Aceptar!',
                title: "<?php echo e(session('actualizar')); ?>",
            })
        </script>
    <?php endif; ?>

    <?php if(session('eliminar')): ?>
        <script>
            Swal.fire({
                icon: 'success',
                confirmButtonText: 'Aceptar!',
                title: "<?php echo e(session('eliminar')); ?>",
            })
        </script>
    <?php endif; ?>


    <script>
        Livewire.on('SCreate', modal => {
            $(modal).modal('close');
        })
    </script>

    <script>
        Livewire.on('delete', tallerId =>{
            Swal.fire({
                title: '¿Estás seguro que quieres eliminar a este taller?',
                showDenyButton: true,
                confirmButtonText: 'Eliminar',
                denyButtonText: `Cancelar`,
                }).then((result) => {
                /* Read more about isConfirmed, isDenied below */
                if (result.isConfirmed) {
                    Livewire.emitTo('crud-taller','destroye', tallerId);
                }
            })
        })
    </script>

    <script>
        Livewire.on('mensaje', (mensaje, icono) => {
            Swal.fire({
                title: mensaje,
                icon: icono,
                confirmButtonColor: '#3085d6',
                confirmButtonText: 'Aceptar'
            })
        })
    </script>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.materialize4', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/talleresadmin.blade.php ENDPATH**/ ?>