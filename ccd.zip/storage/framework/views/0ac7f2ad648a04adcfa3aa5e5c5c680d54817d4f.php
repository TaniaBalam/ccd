

<?php $__env->startSection('head'); ?>
    Periodos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
    Periodos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('crud-periodo', [])->html();
} elseif ($_instance->childHasBeenRendered('jnlmpvE')) {
    $componentId = $_instance->getRenderedChildComponentId('jnlmpvE');
    $componentTag = $_instance->getRenderedChildComponentTagName('jnlmpvE');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jnlmpvE');
} else {
    $response = \Livewire\Livewire::mount('crud-periodo', []);
    $html = $response->html();
    $_instance->logRenderedChild('jnlmpvE', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('modal'); ?>
 
    <script>
        Livewire.on('SCreate', modal => {
            $(modal).modal('close');
        })
    </script>

    <script>
        Livewire.on('delete', tallerId =>{
            Swal.fire({
                title: '¿Estás seguro que quieres eliminar a este taller?',
                showDenyButton: true,
                confirmButtonText: 'Eliminar',
                denyButtonText: `Cancelar`,
                }).then((result) => {
                /* Read more about isConfirmed, isDenied below */
                if (result.isConfirmed) {
                    Livewire.emitTo('crud-periodo','destroye', tallerId);
                }
            })
        })
    </script>

    <script>
        Livewire.on('mensaje', (mensaje, icono) => {
            Swal.fire({
                title: mensaje,
                icon: icono,
                confirmButtonColor: '#3085d6',
                confirmButtonText: 'Aceptar'
            })
        })
    </script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.materialize4', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/periodosadmin.blade.php ENDPATH**/ ?>