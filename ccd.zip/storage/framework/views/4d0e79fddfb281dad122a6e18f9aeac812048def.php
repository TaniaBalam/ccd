

<?php $__env->startSection('head'); ?>
    Actualiza tu perfil
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
    Actualiza tu perfil
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('perfil-alumno', [])->html();
} elseif ($_instance->childHasBeenRendered('HRovYgT')) {
    $componentId = $_instance->getRenderedChildComponentId('HRovYgT');
    $componentTag = $_instance->getRenderedChildComponentTagName('HRovYgT');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('HRovYgT');
} else {
    $response = \Livewire\Livewire::mount('perfil-alumno', []);
    $html = $response->html();
    $_instance->logRenderedChild('HRovYgT', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('modal'); ?>

    <script>
        Livewire.on('SCreate', modal => {
            $(modal).modal('close');
        })
    </script>

    <script>
        Livewire.on('mensaje', (mensaje, icono) => {
            Swal.fire({
                title: mensaje,
                icon: icono,
                confirmButtonColor: '#3085d6',
                confirmButtonText: 'Aceptar'
            })
                Livewire.emitTo('perfil-maestro','cargar');
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.materialize2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/actualizaralumno.blade.php ENDPATH**/ ?>