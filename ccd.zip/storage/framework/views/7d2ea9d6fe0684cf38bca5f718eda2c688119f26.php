

<?php $__env->startSection('head'); ?>
    Asistencias
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
    Asistencias <?php echo e(Str::lower($tallers->taller)); ?> <?php echo e($tallers->periodo->periodo); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

    <?php if($alumnos->count() == 0): ?>

        <div class="center">
            <p class="white-text cuerpo">Aún no se han inscrito tus alumnos en el taller</p>
            <img class="circle" width="250px" height="250px" src="https://i0.wp.com/gatolia.com/wp-content/uploads/2021/04/dibujos-animados-lindo-regreso-escuela-gatos-leyendo-libro_39961-1362.jpg?resize=626%2C450&ssl=1">
        </div>
        
    <?php else: ?>

    <form method="POST" action="/maestro/asistencias/store">
        <?php echo csrf_field(); ?>

        <a  style="background:#B8860B" href="<?php echo e(route('editasistenciasmaestro', $id)); ?>" class="waves-effect waves-light btn-small ">Editar asistencias<i class="material-icons right">edit</i></a>
        <br><br>
        
        <div class="row">
            <div class="col s4">
                <span class="white-text cuerpo">Fecha:</span>
                <input name="fecha" id="fecha" type="date" class="<?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> grey lighten-2" value="<?php echo e(old('fecha')); ?>">
                <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="alert alert-danger red-text"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div>
            <!-- mensaje para error de fecha -->
            <?php if(session('error')): ?>
                <span class="red-text"><?php echo e(session('error')); ?></span>
            <?php endif; ?>
        </div>
        <br>

        <div class="right">
            <button style="background:#B8860B" class="waves-effect waves-light btn-small">Guardar asistencias<i class="material-icons right">save</i></button>  
        </div>
        <br><br>

        <input name="taller" id="taller" type="hidden" value="<?php echo e($tallers->id); ?>">
        
        
        <input style="background:#008F39" class="waves-effect waves-light" type="button" id="BtnSeleccionar" value="Marcar todos">
        <input style="background:#BF0820" class="waves-effect waves-light" type="button" id="BtnDeseleccionar" value="Desmarcar todos">
        <br><br>
        

        <table class="highlight responsive-table titulo">
                
            <thead class="indigo">
                <th>Matrícula</th>
                <th>Alumno</th>  
                <th>Asistencia</th>

            </thead>
            
            <tbody class="white">
                <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <input name="alumnoid[]" id="alumnoid[]" type="hidden" value="<?php echo e($alumno->id); ?>">
                    <input name="tallerid[]" id="tallerid[]" type="hidden" value="<?php echo e($alumno->taller_id); ?>">
                
                    <tr> 
                        <td><?php echo e($alumno->matricula); ?></td>
                        <td><?php echo e($alumno->user->name .' '. $alumno->user->last_name); ?></td>
                        <td>
                            <select  class="browser-default" id="seleccionar" name="asistencia[]">
                                <option value="2">Falta</option>
                                <option value="1">Asistencia</option>
                            </select>
                        </td>                                           
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
            </tbody>
        </table>
        <br>
 
    </form>

    <?php endif; ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('modal'); ?>

<!--<script>
    $(document).ready(function() {
        $('#BtnSeleccionar').click(function() {
            $('#asis input[type=checkbox]').prop("checked", true);
        });

        $('#BtnDeseleccionar').click(function() {
            $('#asis input[type=checkbox]').prop("checked", false);
        });
    });
</script>-->

<script>
    $(document).ready(function() {
        $('#BtnSeleccionar').click(function() {
            $('select[id="seleccionar"]').val('1');
        });

        $('#BtnDeseleccionar').click(function() {
            $('select[id="seleccionar"]').val('2');
        });

    });
</script>


<!-- mensaje de guardado de asistencia -->
<?php if(session('success')): ?>
    <script>
        Swal.fire({
            icon: 'success',
            confirmButtonText: 'Aceptar!',
            title: "<?php echo e(session('success')); ?>",
        })
    </script>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.materialize3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/asistenciasmaestro.blade.php ENDPATH**/ ?>