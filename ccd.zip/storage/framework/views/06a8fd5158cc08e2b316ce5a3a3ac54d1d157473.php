

<?php $__env->startSection('head'); ?>
    Reporte de asistencias
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
    Reporte de asistencias <?php echo e(Str::lower($tallers->taller)); ?> <?php echo e($tallers->periodo->periodo); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

    <?php if($alumnos->count() == 0): ?>
    
        <div class="center">
            <p class="white-text cuerpo">Aún no se han inscrito tus alumnos en el taller</p>
            <img class="circle" width="250px" height="250px" src="https://i0.wp.com/gatolia.com/wp-content/uploads/2021/04/dibujos-animados-lindo-regreso-escuela-gatos-leyendo-libro_39961-1362.jpg?resize=626%2C450&ssl=1">
        </div>

    <?php else: ?>


        <p class="white-text cuerpo">No. de asistencias: <?php echo e($asistencias); ?></p>

        <table class="highlight responsive-table titulo">
                
            <thead class="indigo">
                <th>Matrícula</th>
                <th>Alumno</th>
                <th>Asistencias</th>
                <th>Faltas</th>
                <th>Porcentaje de asistencia</th>
                <th>Derecho a acreditación</th>
                    
            </thead>
                
                <tbody class="white">
                    <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr> 
                            <td><?php echo e($alumno->matricula); ?></td>
                            <td><?php echo e($alumno->user->name); ?> <?php echo e($alumno->user->last_name); ?></td> 
                            <td><?php echo e($alumno->asistencias->where('af','=', 1)->count()); ?></td> 
                            <td><?php echo e($alumno->asistencias->where('af','=', 2)->count()); ?></td>
                            
                            <?php if($alumno->asistencias->count()>=1): ?>
                                <td><?php echo e(($alumno->asistencias->where('af','=', 1)->count()*100)/$asistencias); ?>%</td>
                            <?php else: ?>
                                <td>0%</td>  
                            <?php endif; ?>

                             
                            <?php if($alumno->asistencias->where('af','=', 1)->count()>=$f && $alumno->asistencias->count()>=1): ?>
                                <td><i class="material-icons green-text">check</i></td>
                            <?php else: ?>
                                <td><i class="material-icons red-text">close</i></td> 
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
                </tbody>
        </table>
        <br>

        
    <?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.materialize3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/reporteasismaestro.blade.php ENDPATH**/ ?>