

<?php $__env->startSection('head'); ?>
    Datos del maestro
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
    Datos del maestro
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

<div class="row cuerpo">

    <div class="container">
        <div class="card white">
            <b><p style="color:#1B396A;font-size:larger" class="center">¡Ya casi acabas tu registro! Solo necesitamos que nos proporciones algo más de información sobre ti.</p></b>
        </div>
    </div>
  
  <div class="col s8 offset-s2 white">
        <div class="center">
            <br>

            <img class="circle" src="https://brandem.mx/wp-content/uploads/2018/12/FELINOS_mascota.jpg" width="150px" height="150px">
        </div>

        

        <form method="POST" action="/maestro/store">
            <?php echo csrf_field(); ?>

            <div class="container">


                <div class="input-field">
                    <span> Número de maestro: </span> 
                    <input id="numero" name="numero" type="text" class="<?php $__errorArgs = ['numero'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> grey lighten-2"  value="<?php echo e(old('numero')); ?>" autofocus>

                    <?php $__errorArgs = ['numero'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="alert alert-danger red-text"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    
                </div>

 
           
                <br>

                    
                <div class="center">
                    <button class="waves-effect waves-light btn-small">Enviar datos<i class="fa-solid fa-paper-plane right" ></i></button>
                </div>

            </div>
            
        </form>
        
        <br>
    </div>

</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('modal'); ?>
    <?php if(session('error')): ?>
        <script>
            Swal.fire({
                icon: 'error',
                confirmButtonText: 'Aceptar!',
                title: "<?php echo e(session('error')); ?>",
            })
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.materialize', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/crearmaestro.blade.php ENDPATH**/ ?>