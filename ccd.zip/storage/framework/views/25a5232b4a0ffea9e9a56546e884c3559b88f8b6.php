

<?php $__env->startSection('head'); ?>
    Talleres
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
    Talleres
<?php $__env->stopSection(); ?>


<?php $__env->startSection('bienvenida'); ?>
    
    <header>
        <section class="cabecera">
            <?php if(date('H')< 12): ?>
                <b><span style="font-size:xx-large; background:white" class="titulo">¡Hola, buenos días <?php echo e(Auth::user()->name.' '.Auth::user()->last_name); ?>!</span></b>    

            <?php elseif(date('H') >= 12 && date('H') <= 18): ?>
                <b><span style="font-size:xx-large; background:white" class="titulo">¡Hola, buenas tardes <?php echo e(Auth::user()->name.' '.Auth::user()->last_name); ?>!</span></b>    
            

            <?php elseif(date('H')>= 18 && date('H')<= 24): ?>
                <b><span style="font-size:xx-large; background:white" class="titulo">¡Hola, buenas noches <?php echo e(Auth::user()->name.' '.Auth::user()->last_name); ?>!</span></b>    
            <?php endif; ?>
        </section>
    </header>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

    
    <?php if($tallers->count()==0): ?>

        <div class="center">
            <p class="white-text cuerpo">No tiene talleres asignados en este periodo</p>
            <img class="circle" width="250px" height="250px" src="https://img.freepik.com/vector-gratis/dibujos-animados-lindo-regreso-escuela-gatos-clase_39961-1282.jpg">
        </div>
        
    <?php else: ?>

    <p class="center white-text cuerpo">Estos son los talleres que imparte</p>

    <div class="row">
        <?php $__currentLoopData = $tallers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col s12 m6">
                <div class="card sticky-action" style="height=250px">
                    <div class="card-image waves-effect waves-block waves-light">
                        <img class="activator" src="<?php echo e($taller->imagen); ?>" height="200px">
                    </div>

                    <div class="card-content">
                        <span class="card-title activator grey-text text-darken-4"><b><?php echo e($taller->taller); ?> <?php echo e($taller->periodo->periodo); ?></b><i class="material-icons right">more_vert</i></span>
                        <p>Número de alumnos: <?php echo e($taller->alumnos->count()); ?></p>
                        <p>Horario: <?php echo e(Str::limit ($taller->horario, 25)); ?></p>
                        
                    </div>

                    <div class="card-action center">
                        
                        <a style="color:#B8860B" href="<?php echo e(route('vistaveralumnosmaestro', $taller->id)); ?>"><i class="material-icons">group</i>Alumnos</a>
                        <a style="color:#B8860B" href="<?php echo e(route('asistenciasmaestro', $taller->id)); ?>"><i class="material-icons">assignment_turned_in</i>Asistencias</a>
                        <br><br>
                        <a style="color:#B8860B" href="<?php echo e(route('repoasistenciasmaestro', $taller->id)); ?>"><i class="material-icons">event_note</i>Reporte de asistencias</a>
                          
                    </div>

                    <div class="card-reveal">
                        <span class="card-title grey-text text-darken-4"><b><?php echo e($taller->taller); ?> <?php echo e($taller->periodo->periodo); ?></b><i class="material-icons right">close</i></span>
                        <p>Número de alumnos: <?php echo e($taller->alumnos->count()); ?></p>
                        <p>Horario: <?php echo e($taller->horario); ?></p>                              
                    </div>  
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>


    <a href="" class="btn-flotante">Es hora de poner asistencias <img src="https://acegif.com/wp-content/uploads/cat-typing-1.gif" width="50px" height="50px"> </a>


    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.materialize3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/alumnosmaestro.blade.php ENDPATH**/ ?>