

<?php $__env->startSection('head'); ?>
    Asistencias
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
    <?php if(empty($alumno->taller_id)): ?>
        Asistencias 
    <?php else: ?>
        Tus asistencias en <?php echo e(Str::lower($alumno->taller->taller)); ?> <?php echo e($alumno->taller->periodo->periodo); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

    <?php if(empty($alumno->taller_id)): ?>

        <div class="center cuerpo">
            <p class="white-text">Vaya parece que no te has inscrito a ningún taller</p>
            <p class="white-text">Inscríbete para poder empezar a recibir asistencias</p>
            <img class="circle" width="250px" height="250px" src="https://img.freepik.com/vector-gratis/dibujos-animados-lindo-regreso-escuela-gato-libro_39961-1299.jpg">
        </div>

    <?php else: ?>

        <?php if($alumno->asistencias->count()==0): ?>
            <div class="center cuerpo">
                <p class="white-text">Por ahora, no tienes asistencias aplicadas</p>
                <p class="white-text">Vuelve más tarde para ver si hay asistencias nuevas</p>
                
                <img class="circle" width="250px" height="250px" src="https://img.freepik.com/vector-gratis/dibujos-animados-lindo-regreso-escuela-gato-aula_39961-1328.jpg?w=2000">
            </div>
        <?php else: ?>


            <div class="center">
                <?php if(now()->toDateString()>=$alumno->taller->periodo->fecha_expiracion && $asistencias2>=$f): ?>
                    <p style="color:#008F39" class="cuerpo">¡Yuju! ya puedes descargar tu acreditación del taller ¡Enhorabuena!</p>
                    <div class="cuerpo">
                        <a href="<?php echo e(route('acreditacion')); ?>" style="background:#008F39" class="waves-effect waves-light btn-small">Descargar acreditación<i class="material-icons right">file_download</i></a>
                    </div>
                <?php else: ?>
                    <p style="color:#008F39" class="cuerpo">Podrás descargar tu acreditación cuando el periodo acabe y tengas al menos el 70% de tus asistencias</p>
                    <div class="cuerpo">
                        <a href="<?php echo e(route('acreditacion')); ?>" disabled class="waves-effect waves-light btn-small">Descargar acreditación<i class="material-icons right">file_download</i></a>
                    </div>
                <?php endif; ?>
            </div> 

            <br>


            <div class="row">



                                                    
                <?php if($asistencias3>=3): ?>                       
                    <div class="center">
                        <img class="responsive-img" width="150px" height="70px" src="https://acegif.com/wp-content/gifs/sad-cat-66.gif">
                        <span class="yellow-text">Has faltado mucho al taller</span>
                    </div>
                <?php elseif($asistencias3==0 && $asistencias2>=1): ?>

                    <div class="center">
                        <img class="responsive-img" width="150px" height="70px" src="https://i.pinimg.com/originals/f2/58/99/f258997a921c7f6c2ebf19ebcd25cfa7.gif">
                        <span class="yellow-text">No tienes ninguna falta ¡Bien hecho!</span>
                    </div>
                <?php endif; ?>


                

                <div class="col s12 m6">
                    <p class="white-text cuerpo">Porcentaje de asistencia: <?php echo e($porcasis); ?>%</p>


                    <table class="highlight responsive-table titulo">
                            
                        <thead class="indigo">
                            <th>Fecha</th>
                            <th>Asistencia</th>
                                
                        </thead>
                            
                            <tbody class="white">
                                <?php $__currentLoopData = $asistenciasalum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asistencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                    <tr> 
                                        <td><?php echo e($asistencia->fecha); ?></td> 
                                        <?php if($asistencia->af ==1): ?>                                      
                                            <td><i class="material-icons green-text">check</i></td>
                                        <?php else: ?>
                                            <td><i class="material-icons red-text">close</i></td>
                                        <?php endif; ?>
                                    </tr>
                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
                            </tbody>
                    </table>
                    <br>

                </div>

                <div class="col s12 m6">
                    <br><br>
                    <div class="card white">
                        <canvas style="max-width:700px;max-height:300px;"  id="asis" ></canvas>
                    </div>
                </div>

            </div>


            
        <?php endif; ?>

    <?php endif; ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('graficas'); ?>

<script>
    
    var xValues = ["Asistencias","Faltas"];
    var yValues = [<?php echo e(Js::from($asistencias2)); ?>,<?php echo e(Js::from($asistencias3)); ?>];
    var barColors = ["#008F39", "#BF0820"];
    new Chart(document.getElementById("asis"), {
        type: "doughnut",
        data: {
            labels: xValues,
            datasets: [{
            backgroundColor: barColors,
            data: yValues
            }]
        },
       
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.materialize2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/asistenciasalumno.blade.php ENDPATH**/ ?>