

<?php $__env->startSection('head'); ?>
    Talleres
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
    Talleres
<?php $__env->stopSection(); ?>



<?php $__env->startSection('bienvenida'); ?>

    <header>
        <section class="cabecera">
            <?php if(date('H')< 12): ?>
                <b><span style="font-size:xx-large; background:white" class="titulo">¡Hola, buenos días <?php echo e($Alumno->user->name .' '. $Alumno->user->last_name); ?>!</span></b>    

            <?php elseif(date('H') >= 12 && date('H') <= 18): ?>
                <b><span style="font-size:xx-large; background:white" class="titulo">¡Hola, buenas tardes <?php echo e($Alumno->user->name .' '. $Alumno->user->last_name); ?>!</span></b>    
            

            <?php elseif(date('H')>= 18 && date('H')<= 24): ?>
                <b><span style="font-size:xx-large; background:white" class="titulo">¡Hola, buenas noches <?php echo e($Alumno->user->name .' '. $Alumno->user->last_name); ?>!</span></b>    
            <?php endif; ?>
        </section>
    </header>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('talleres-alumno', [])->html();
} elseif ($_instance->childHasBeenRendered('KvxIHTh')) {
    $componentId = $_instance->getRenderedChildComponentId('KvxIHTh');
    $componentTag = $_instance->getRenderedChildComponentTagName('KvxIHTh');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('KvxIHTh');
} else {
    $response = \Livewire\Livewire::mount('talleres-alumno', []);
    $html = $response->html();
    $_instance->logRenderedChild('KvxIHTh', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
   
<?php $__env->stopSection(); ?>


<?php $__env->startSection('modal'); ?>

    <script>
        Livewire.on('inscripcion', tallerId =>{
            Swal.fire({
                title: '¿Estás seguro que quieres inscribirte a este taller? Una vez inscrito no podrás cambiarlo.',
                showDenyButton: true,
                confirmButtonText: 'Incribirme',
                denyButtonText: `Cancelar`,
                }).then((result) => {
                /* Read more about isConfirmed, isDenied below */
                if (result.isConfirmed) {
                    Livewire.emitTo('talleres-alumno','inscribirse', tallerId);
                }
            })
        })
    </script>

    <script>
        Livewire.on('mensaje', (mensaje, icono) => {
            Swal.fire({
                title: mensaje,
                icon: icono,
                confirmButtonColor: '#3085d6',
                confirmButtonText: 'Aceptar'
            })
        })
    </script>

    <script>
        Livewire.on('SCreate', modal => {
            $(modal).modal('close');
        })
    </script>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.materialize2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/talleresalumno.blade.php ENDPATH**/ ?>