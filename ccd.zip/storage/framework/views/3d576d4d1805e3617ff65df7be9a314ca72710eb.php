
<!-- Modal Structure -->
<div wire:ignore.self id="perfil" class="center modal black cuerpo col s12 m6">

    <h2 class="white-text">Actualizar imagen </h2>

    <?php if($imagen): ?>
        <div class="center">
            <br>
            <img class="circle" src="<?php echo e($imagen->temporaryUrl()); ?>" width="100px" height="100px">
        </div>
    <?php else: ?>
        <div class="center">
            <br>
            <img class="circle" src="<?php echo e($urlimagen); ?>"  width="100px" height="100px">
        </div>
    <?php endif; ?>

    <div class="modal-content">
        <form wire:submit.prevent="imgperfil">
            <span class="white-text">Seleccionar imagen:</span> 
            <input class="white" type="file" wire:model="imagen">
            <?php $__errorArgs = ['imagen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="red-text"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <div class="modal-footer black">
                <br>
                <button style="background:#1B396A" wire:loading.attr="disabled" wire:target="imagen" type="submit" class="waves-effect waves-light btn-small">Actualizar imagen<i class="fa-solid fa-paper-plane right" ></i></button>
            
                <button style="background:#BF0820"  type="button" class="modal-close waves-effect btn-small">Cerrar<i class="fa-solid fa-xmark right"></i></button>
            </div>
            
        </form>
    </div>
</div><?php /**PATH C:\xampp\htdocs\project\resources\views/livewire/perfil/perfil.blade.php ENDPATH**/ ?>