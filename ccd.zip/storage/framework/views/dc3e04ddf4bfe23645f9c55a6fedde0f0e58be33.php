

<?php $__env->startSection('head'); ?>
    Actualiza tu perfil
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
    Actualiza tu perfil
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('perfil-admin', [])->html();
} elseif ($_instance->childHasBeenRendered('MvBJHmM')) {
    $componentId = $_instance->getRenderedChildComponentId('MvBJHmM');
    $componentTag = $_instance->getRenderedChildComponentTagName('MvBJHmM');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('MvBJHmM');
} else {
    $response = \Livewire\Livewire::mount('perfil-admin', []);
    $html = $response->html();
    $_instance->logRenderedChild('MvBJHmM', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('modal'); ?>

    <script>
        Livewire.on('SCreate', modal => {
            $(modal).modal('close');
        })
    </script>

    <script>
        Livewire.on('mensaje', (mensaje, icono) => {
            Swal.fire({
                title: mensaje,
                icon: icono,
                confirmButtonColor: '#3085d6',
                confirmButtonText: 'Aceptar'
            })
                Livewire.emitTo('perfil-admin','cargar');
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.materialize4', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/actualizaradmin.blade.php ENDPATH**/ ?>