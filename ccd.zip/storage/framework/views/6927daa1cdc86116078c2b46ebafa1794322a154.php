
<!-- Modal Trigger -->
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar alumno')): ?>
    <a style="background:#B8860B" class="btn col s12 modal-trigger" href="#modal1"><i class="material-icons left">person_add</i>Crear alumno</a>
    <br><br>
<?php endif; ?>

<!-- Modal Structure -->
<div wire:ignore.self id="modal1" class="modal black cuerpo">

    <div class="center">
        <br>
        <img class="circle" src="https://brandem.mx/wp-content/uploads/2018/12/FELINOS_mascota.jpg" width="100px" height="100px">
    </div>

    <div class="modal-content">
        <form wire:submit.prevent="submit">



        <span class="white-text">Nombre(s):</span> 
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="red-text"> <?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <input type="text"  class="grey lighten-2" wire:model="name" >

        <span class="white-text">Apellido(s):</span> 
        <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="red-text"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <input type="text"  class="grey lighten-2" wire:model="last_name" >

        <span class="white-text">Correo institucional:</span> 
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="red-text"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <input type="email"  class="grey lighten-2" wire:model="email" >  

        <span class="white-text"> Contraseña: </span> 
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="red-text"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <input wire:model="password" type="password"  class="grey lighten-2" autocomplete="new-password">

        <div>
            <span class="white-text">Edad:</span> 
            <?php $__errorArgs = ['edad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="red-text"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <input type="number"  class="grey lighten-2" wire:model="edad" >
        </div>
        <br>

        <div>
            <span class="white-text">Sexo:</span> 
            <label >
                <input wire:model="sexo" class="with-gap" value="1" <?php echo e((old('sexo') == 1) ? 'checked' : ''); ?> name="sexo" type="radio" />
                <span>Masculino</span>
            </label>


            <label> 
                <input wire:model="sexo" class="with-gap" value="2" <?php echo e((old('sexo') == 2) ? 'checked' : ''); ?> name="sexo" type="radio" />
                <span>Femenino</span>
            </label> 
            <?php $__errorArgs = ['sexo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="red-text"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
        </div>
        <br>

        <span class="white-text">Teléfono:</span>
        <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="red-text"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
        <input type="number"  class="grey lighten-2" wire:model="telefono" > 

        <span class="white-text">Carrera</span>
        <?php $__errorArgs = ['carrera'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="red-text"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
        <select wire:model="carrera" name="carrera" class="browser-default grey lighten-2">
            <option value="" selected> </option>
            <option value="1" <?php echo e(old('carrera') == 1 ? 'selected' : ''); ?>>Ingeniería en Sistemas Computacionales</option>
            <option value="2" <?php echo e(old('carrera') == 2 ? 'selected' : ''); ?>>Ingeniería Industrial</option>
            <option value="3" <?php echo e(old('carrera') == 3 ? 'selected' : ''); ?>>Ingeniería Electrónica</option>
            <option value="4" <?php echo e(old('carrera') == 4 ? 'selected' : ''); ?>>Ingeniería en Energías Renovables</option>
            <option value="5" <?php echo e(old('carrera') == 5 ? 'selected' : ''); ?>>Ingeniería Electromécanica</option>
        </select>
        <br>

        <div>
        <span class="white-text">Cultura etnia:</span>            
        <label>
            <input wire:model="cult" class="with-gap" value="1" <?php echo e((old('culturaetnia') == 1) ? 'checked' : ''); ?> name="culturaetnia" type="radio" />
            <span>Si</span>
        </label>

        <label>
            <input wire:model="cult" class=" with-gap" value="2" <?php echo e((old('culturaetnia') == 2) ? 'checked' : ''); ?> name="culturaetnia" type="radio" />
            <span>No</span>
        </label> 
        <?php $__errorArgs = ['cult'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="red-text"> <?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <br>

        <span class="white-text">Municipio:</span>
        <?php $__errorArgs = ['muni'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="red-text"> <?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <select wire:model="muni" name="municipio" class="browser-default grey lighten-2" >
       
        <option hidden value=""></option>
            <?php $__currentLoopData = $municipio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipios): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($municipios->id); ?>" <?php echo e(old('municipio') == $municipios->id ? "selected" :""); ?>><?php echo e($municipios->municipio); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br>

        <div>
            <span class="white-text">Discapacidad:</span>                
            <label>
                <input wire:model="discapacidad" class="with-gap" value="1" <?php echo e((old('discapacidad') == 1) ? 'checked' : ''); ?> name="discapacidad" type="radio" />
                <span>Si</span>
            </label>

            <label>
                <input wire:model="discapacidad" class="with-gap" value="2" <?php echo e((old('discapacidad') == 2) ? 'checked' : ''); ?> name="discapacidad" type="radio" />
                <span>No</span>
            </label> 
            <?php $__errorArgs = ['discapacidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="red-text"> <?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <br>
        
        <span class="white-text">Taller:</span> 
        <?php $__errorArgs = ['taller'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="red-text"> <?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <select name="taller" class=" browser-default grey lighten-2" wire:model="taller">
        <option hidden value=""></option>
        <?php $__currentLoopData = $talleres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tallers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($tallers->id); ?>" <?php echo e(old('taller') == $tallers->id ? "selected" :""); ?>><?php echo e($tallers->taller); ?> <?php echo e($tallers->periodo->periodo); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br>

        <div class="modal-footer black">
            <button style="background:#1B396A" type="submit" class="waves-effect waves-light btn-small">Enviar datos<i class="fa-solid fa-paper-plane right" ></i></button>
            
            <button style="background:#BF0820" wire:click="resetInput()" type="button" class="modal-close waves-effect btn-small">Cerrar<i class="fa-solid fa-xmark right"></i></button>
        </div>
        </form>
    </div>
</div><?php /**PATH C:\xampp\htdocs\project\resources\views/livewire/alumno/create.blade.php ENDPATH**/ ?>