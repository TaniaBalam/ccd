

<div>

    
    <div class="row">
        <input class="col m3 s6 white" placeholder="Buscar por taller" type="text" wire:model="buscador">

        <button class="btn color" style="height:45px" wire:click="render()"><i class="fa-solid fa-magnifying-glass"></i></i></button>
    </div>
    
    <?php echo $__env->make('livewire.taller.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('livewire.taller.update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <br><br>

    <table class="highlight responsive-table titulo">
        
        <thead class="indigo">
            <th>Taller</th>
            <th>Descripción</th>
            <th>Maestro</th>
            <th>Horario</th>
            <th>Periodo</th>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('eliminar alumno')): ?>
                <th>Acciones</th>
            <?php endif; ?>
           
            
                            
        </thead>
        
        <tbody class="white">
            <?php if($tallers->count() <> 0): ?>
                <?php $__currentLoopData = $tallers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                    <tr> 
                        <td><?php echo e($taller->taller); ?></td>                                           
                        <td><?php echo e($taller->descripcion); ?></td>
                        <?php if(empty($taller->maestro->user->name)): ?>
                            <td>Sin maestro</td>
                        <?php else: ?>
                            <td><?php echo e($taller->maestro->user->name .' '. $taller->maestro->user->last_name); ?></td>   
                        <?php endif; ?>

                        <td><?php echo e($taller->horario); ?></td>
                        <td><?php echo e($taller->periodo->periodo); ?></td>
                    
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('eliminar alumno')): ?>
                            <td>  
                                <div>
                                    <a style="background:green" class="btn col s12 modal-trigger" href="#modal2" wire:click="edit(<?php echo e($taller->id); ?>)"><i class="material-icons">edit</i></a>
                                </div>
                                <br>
                                <div>
                                    <a style="background:red" class="btn col s12" wire:click="$emit('delete', <?php echo e($taller->id); ?>)"><i class="material-icons">delete</i></a>
                                </div>
                            </td>
                        <?php endif; ?>
                        
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- mensaje de que no hay talleres -->
            <?php else: ?>
                
                <tr>
                    <td class="center" colspan="6">
                        <br>
                        <i class="fa-solid fa-triangle-exclamation">&nbsp No se encontraron datos</i>
                        <br></br>
                    </td>
                </tr>

            <?php endif; ?>
                        
        </tbody>
    </table>
    <br><br>

 
    <?php echo e($tallers->links('vendor.pagination.materializecss')); ?>

</div>
<?php /**PATH C:\xampp\htdocs\project\resources\views/livewire/crud-taller.blade.php ENDPATH**/ ?>